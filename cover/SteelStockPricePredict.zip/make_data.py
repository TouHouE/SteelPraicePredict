import pandas as pd
from nkust.steel_price.helper.sql_controller import ToDoTabeManager

MAPS = {'taiwan': '台灣鋼鐵指數',
        'djusst': '道瓊鋼鐵指數',
        'steel': '鋼筋價格指數'}
TYPE_MAP = {
    'D': 'daily',
    'M': 'monthly'
}
TEN_DAY = pd.to_timedelta('10d')
ONE_DAY = pd.to_timedelta('1d')
SIX_M = pd.to_timedelta(f'{30 * 6}d')
ONE_M = pd.to_timedelta('30d')
DB = ToDoTabeManager()
DB.connect_to_db()

def M(how_long: int):
    return pd.to_timedelta(f'{30 * how_long}d')


def D(how_long: int):
    return pd.to_timedelta(f'{how_long}d')


def monthly(name: str, start_date, range=6):
    """

    :param name: the stock name, like djusst, taiwan, steel...
    :param range: how long you want to predict
    :return:
    """
    range = int(range)
    RANGE_M = M(range)
    df = DB.load_table("commodity_monthly")
    df = df[df['c_name'] == MAPS[name]] # split DataFrame by column value

    end_date = start_date + RANGE_M
    start_date = start_date + ONE_M
    future_date = pd.date_range(start_date, end_date, freq='1M')

    df_param = df[['c_open', 'c_high', 'c_low']]
    future_param = df_param.iloc[:range].reset_index()
    date = pd.DataFrame({'c_date': future_date})
    future_ = pd.concat([date, future_param], axis=1)
    future_.drop(['index'], axis=1, inplace=True)
    return future_

def daily(name: str, start_date, range=10, ):
    """

    :param name: the stock name
    :param range: how long you want to predict
    :return:
    """
    range = int(range)
    RANGE_D = D(range)

    df = DB.load_tabe('commodity_daily')
    df = df[df['c_name'] == MAPS[name]]

    end_date = start_date + RANGE_D
    start_date = start_date + ONE_DAY

    #Produce whole date
    future_date = pd.date_range(start_date, end_date, freq='1d')

    df_param = df[['c_open', 'c_high', 'c_low']]
    future_param = df_param.iloc[:range].reset_index()# predict part

    date = pd.DataFrame({'c_date': future_date})

    future_ = pd.concat([date, future_param], axis=1)
    future_.drop(['index'], axis=1, inplace=True)

    return future_


def start(is_daily: bool, stock_name: str, start_date, range: int):
    return daily(name=stock_name, start_date=start_date, range=range) if is_daily else monthly(stock_name, range)




