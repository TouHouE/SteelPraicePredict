# How to install package:
   由於Prophet套件的安裝方式在windows與Linux上略有不同，因此詳細安裝方式請參考官方[github](https://github.com/facebook/prophet)
# How to use:
        python predict.py --start_date "2020-09-20" --predict_range "10D"
# What meaning with those arguments:
        --start_date:   預測起始日期，請勿超出DataBase裡的最後日期。\\
                     格式為"年年年年-月月-日日"

        --predict_range:        預測未來時間的長度，後半部分為時間單位為天(D)或月(M)前半部分表示長度。


# TODO: 修正期始日期不可超過DataBase中最後的日期
