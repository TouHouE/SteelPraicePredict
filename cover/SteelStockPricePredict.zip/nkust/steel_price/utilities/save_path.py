class SavePath:
    def __init__(self):
        self.CSV_PATH = './csv'
        self.MODEL_PATH = './model'
        self.PREDICT_PATH = './predict'
        self.VALIDATE_PATH = './csv/predict_validation'
        self.TRAIN_PATH = './sql'
        self.IMG_PATH = './model/img'


PATH = SavePath()